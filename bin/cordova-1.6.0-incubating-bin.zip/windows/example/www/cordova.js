
document.write('<script type="text/javascript" charset="utf-8" src="cordova-1.5.0.js"></script>');