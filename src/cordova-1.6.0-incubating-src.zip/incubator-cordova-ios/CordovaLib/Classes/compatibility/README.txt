Include these headers if you are using a bleeding edge plugin in an older version of Cordova.

1.5.0 -- only for 1.5.0 projects
0.9.6 -- for projects between 0.9.6 and 1.4.1